
#include "mex.h"
#include "math.h"
#include "float.h"

/** [A, b] = ma_lse_allcons(X) */
void mexFunction(int nlhs, mxArray** plhs, int nrhs, const mxArray** prhs)
{
    if (nrhs != 1) mexErrMsgTxt("Invalid number of input arguments.");
    if (nlhs > 2) mexErrMsgTxt("Invalid number of output arguments.");
    const int n = mxGetM(prhs[0]); // number of samples
    const int d = mxGetN(prhs[0]); // domain dimension
    const int nd = n*d;

    if (mxIsSparse(prhs[0])) mexErrMsgTxt("Sparse X is not supported.");
    if (0 == nlhs) return;

    const int m = n*(n-1);
    plhs[0] = mxCreateSparse(n+2*nd, m, m*2*(1+d), mxREAL); // A'
    if (nlhs == 2) plhs[1] = mxCreateSparse(m, 1, 0, mxREAL);

    double* pAv = (double*) mxGetPr(plhs[0]);
    mwIndex* pAr = mxGetIr(plhs[0]);
    mwIndex* pAc = mxGetJc(plhs[0]);

    const double* pX = (double*) mxGetPr(prhs[0]);
    mwIndex i, j, k;
    int r, t, tn, w;
    double v;

    k = 0;
    r = 0;
    w = n;
    pAc[0] = 0;
    for (i = 0; i < n; ++i)
    {
        for (j = 0; j < n; ++j)
        {
            if (i == j) continue;

            if (i < j)
            {
                // A(k,i) = 1
                pAv[r] = +1.0;
                pAr[r] = i;
                ++r;

                // A(k,j) = -1
                pAv[r] = -1.0;
                pAr[r] = j;
                ++r;
            }
            else // pAr has to be ordered inside column ranges
            {
                // A(k,j) = -1
                pAv[r] = -1.0;
                pAr[r] = j;
                ++r;

                // A(k,i) = 1
                pAv[r] = +1.0;
                pAr[r] = i;
                ++r;
            }

            // w = n + (i-1)*d2 + [1:d]
            // A(k,w) = X(j,:) - X(i,:)
            // A(k,w+d) = -A(k,w)
            for (t = 0, tn = 0; t < d; ++t, tn += n)
            {
                v = pX[tn+j] - pX[tn+i];
                if (fabs(v) < DBL_MIN) continue;

                pAv[r] = v;
                pAr[r] = w+t;
                ++r;
            }
            for (t = 0, tn = 0; t < d; ++t, tn += n)
            {
                v = pX[tn+i] - pX[tn+j];
                if (fabs(v) < DBL_MIN) continue;

                pAv[r] = v;
                pAr[r] = w+t+d;
                ++r;
            }

            pAc[++k] = r;
        }

        w += 2*d;
    }
}
