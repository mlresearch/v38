
function P = P_voronoi(C, X)
% Returns a voronoi partition P of data points X for centers C.
%
    K = size(C,1);
    n = size(X,1);

    P = {};
    P{K} = [];
    for i = 1:n
        [~,ci] = min(sum(bsxfun(@minus, C, X(i,:)).^2, 2));
        P{ci} = [P{ci}; i];
    end
end
