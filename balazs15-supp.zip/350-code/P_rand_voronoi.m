
function P = P_rand_voronoi(X, K)
% Returns a voronoi partition P of data points X
% for uniformly drawn K centers.
%
    [n,d] = size(X);

    P = {};
    inds = randperm(n);
    inds = inds(1:K);
    C = X(inds,:);
    P = P_voronoi(C, X);
end
