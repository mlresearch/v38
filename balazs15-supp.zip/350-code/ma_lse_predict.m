
function [y, active] = ma_lse_predict(model, X, varargin)
% Predicting by a max-affine LSE model.
%
% Usage:
%
%    y = ma_lse_predict(model, X);
%    y = ma_lse_predict(model, X, false);
%    [y, active] = ma_lse_predict(model, X, true);
%
% Input:
%
%    model : max-affine LSE model (fields: B, G, v)
%
%            B : range bound (1x1)
%            G : hyperplane slopes (K x d)
%            v : hyperplane heights (K x 1)
%
%    X : test data points (m x d)
%
%    active_flag : switch on/off the computation of active planes
%                  (optional, default is false)
%
% Output:
%
%    y      : test values (m x 1)
%    active : indices of hyperplane on which the values are attained (m x 1)
%             or zero if the value was lower truncated
%             (only computed if the active flag is on, otherwise empty)
%
    if nargin > 3, error('Too many input arguments.'); end

    if size(X,1) < 1 || size(X,2) < 1, error('Invalid X.'); end
    if ~isfield(model, 'v'), error('Missing model.v.'); end
    if ~isfield(model, 'G'), error('Missing model.G.'); end
    if ~isfield(model, 'B'), error('Missing model.B.'); end
    if ~isscalar(model.B), error('B is not a scalar.'); end
    if size(model.G,1) ~= numel(model.v), error('dim(G,1) ~= dim(v).'); end
    if size(model.G,2) ~= size(X,2), error('dim(G,2) ~= dim(X,2).'); end

    active_flag = false;
    if nargin == 3
        active_flag = varargin{1};
        if ~islogical(active_flag), error('Non-logical active_flag.'); end
    end

    active = [];
    if active_flag
        [y, active] = max(bsxfun(@plus, X*model.G', model.v'), [], 2);
    else
        y = max(bsxfun(@plus, model.G*X', model.v))';
    end

    i = find(y < -model.B);
    if ~isempty(i)
       y(i) = -model.B;
       if active_flag, active(i) = 0; end
    end
end
