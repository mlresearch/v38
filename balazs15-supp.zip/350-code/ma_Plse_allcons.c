
#include "mex.h"
#include "math.h"
#include "float.h"

void fill_coeff_k(int d, int n, int K, double *pX, int tj, double *pXbar,
                  int k, int rk, double *pAv, mwIndex *pAr, int *r)
{
    double v;
    int t, tK, tn;

    for (t = 0, tK = 0, tn = 0; t < d; ++t, tK += K, tn += n)
    {
        v = pX[tn + tj] - pXbar[tK + k];
        //if (fabs(v) < DBL_MIN) continue;

        pAv[*r] = v;
        pAr[*r] = rk + t;
        ++(*r);
    }
    for (t = 0, tK = 0, tn = 0; t < d; ++t, tK += K, tn += n)
    {
        v = pXbar[tK + k] - pX[tn + tj];
        //if (fabs(v) < DBL_MIN) continue;

        pAv[*r] = v;
        pAr[*r] = rk + t + d;
        ++(*r);
    }
}

void fill_coeff_l(int d, int n, int K, double *pX, int tj, double *pXbar,
                  int l, int rl, double *pAv, mwIndex *pAr, int *r)
{
    double v;
    int t, tK, tn;

    for (t = 0, tK = 0, tn = 0; t < d; ++t, tK += K, tn += n)
    {
        v = pXbar[tK + l] - pX[tn + tj];
        //if (fabs(v) < DBL_MIN) continue;

        pAv[*r] = v;
        pAr[*r] = rl + t;
        ++(*r);
    }
    for (t = 0, tK = 0, tn = 0; t < d; ++t, tK += K, tn += n)
    {
        v = pX[tn + tj] - pXbar[tK + l];
        //if (fabs(v) < DBL_MIN) continue;

        pAv[*r] = v;
        pAr[*r] = rl + t + d;
        ++(*r);
    }
}

/** [A, b, Pcounts] = ma_Plse_allcons(X, P, Xbar) */
void mexFunction(int nlhs, mxArray** plhs, int nrhs, const mxArray** prhs)
{
    if (nrhs != 3) mexErrMsgTxt("Invalid number of input arguments.");
    if (nlhs > 3) mexErrMsgTxt("Invalid number of output arguments.");
    const int n = mxGetM(prhs[0]); // number of samples
    const int d = mxGetN(prhs[0]); // domain dimension
    const int d2 = d*2;

    if (mxIsSparse(prhs[0])) mexErrMsgTxt("Sparse X is not supported.");
    if (!mxIsCell(prhs[1])) mexErrMsgTxt("P has to be a cell array.");
    if (mxIsSparse(prhs[2])) mexErrMsgTxt("Sparse Xbar is not supported.");
    if (0 == nlhs) return;

    const mxArray *P = prhs[1];
    const int K = mxGetN(P) * mxGetM(P);
    int k;

    // Calculating the number of constraints.
    int ncons = 0;
    mxArray *cell;
    for (k = 0; k < K; ++k)
    {
        cell = mxGetCell(P,k);
        if (NULL == cell) mexErrMsgTxt("Invalid NULL cell.");
        ncons += mxGetN(cell) * mxGetM(cell);
    }
    ncons *= K-1;

    // Creating output matrices.
    plhs[0] = mxCreateSparse(K*(1+d2), ncons, ncons*2*(1+d2), mxREAL);
    if (nlhs >= 2) plhs[1] = mxCreateSparse(ncons, 1, 0, mxREAL);
    if (nlhs == 3) plhs[2] = mxCreateDoubleMatrix(K, 1, mxREAL);

    double *pAv = (double*) mxGetPr(plhs[0]);
    mwIndex *pAr = mxGetIr(plhs[0]);
    mwIndex *pAc = mxGetJc(plhs[0]);

    double *Pcounts = NULL;
    if (nlhs == 3) Pcounts = (double*) mxGetPr(plhs[2]);

    int rk, l, rl, j, jmax, i, r, tj;
    double *pCell;

    double *pX = (double*) mxGetPr(prhs[0]);
    double *pXbar = (double*) mxGetPr(prhs[2]);

    i = 0;
    r = 0;
    pAc[0] = 0;
    for (k = 0, rk = K; k < K; ++k, rk += d2)
    {
        for (l = 0, rl = K; l < K; ++l, rl += d2)
        {
            if (k == l) continue;

            cell = mxGetCell(P,l);
            if (NULL == cell) mexErrMsgTxt("Invalid NULL cell.");
            pCell = (double*) mxGetPr(cell);

            jmax = mxGetN(cell) * mxGetM(cell);
            if (Pcounts != NULL) Pcounts[k] += jmax;
            for (j = 0; j < jmax; ++j)
            {
                tj = (int)pCell[j] - 1;

                // pAr has to be ordered inside column ranges
                if (k < l)
                {
                    // A(i,k) = 1
                    pAv[r] = +1.0;
                    pAr[r] = k;
                    ++r;

                    // A(i,l) = -1
                    pAv[r] = -1.0;
                    pAr[r] = l;
                    ++r;
                }
                else
                {
                    // A(i,l) = -1
                    pAv[r] = -1.0;
                    pAr[r] = l;
                    ++r;

                    // A(i,k) = 1
                    pAv[r] = +1.0;
                    pAr[r] = k;
                    ++r;
                }
                if (k < l)
                {
                    fill_coeff_k(d, n, K, pX, tj, pXbar, k, rk, pAv, pAr, &r);
                    fill_coeff_l(d, n, K, pX, tj, pXbar, l, rl, pAv, pAr, &r);
                }
                else
                {
                    fill_coeff_l(d, n, K, pX, tj, pXbar, l, rl, pAv, pAr, &r);
                    fill_coeff_k(d, n, K, pX, tj, pXbar, k, rk, pAv, pAr, &r);
                }

                pAc[++i] = r;
            }
        }
    }
    mxSetNzmax(plhs[0], r);
}
