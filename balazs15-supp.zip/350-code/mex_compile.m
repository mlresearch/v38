
function mex_compile(file)
    cflags = '-Wall -O2 -fPIC -std=c99';
    cflags = [cflags ' -DFS_MATLAB'];

    cmd_mex = ['mex CFLAGS=''$CFLAGS ' cflags '''' ...
               ' -o ' file ' -lm -largeArrayDims' ...
               ' ' file '.c'];
    eval(cmd_mex);

    if exist([file '.o'])
        delete([file '.o']);
    end
end
