
function [xsol,fsol,flag,info] = qpsolver(H,f,A,b,varargin)
% [xsol,fsol,flag] = qpsolver(H,f,A,b,Aeq,beq,lb,ub,x0)
%
% Quadratic programming (QP) solver for the system:
%
%    min 0.5*x'*H*x + f'*x  s.t.  A*x <= b, Aeq*x = beq, lb <= x <= ub.
%     x
%
% flags:  0 - solution is optimal
%        -1 - problem is infeasible
%        -9 - unknown error
%
    global use_single_thread_optim;
    global is_mosek;

    Aeq = []; beq = [];
    if nargin >= 6
        Aeq = varargin{1};
        beq = varargin{2};
    end

    lb = []; ub = [];
    if nargin >= 7, lb = varargin{3}; end
    if nargin >= 8, ub = varargin{4}; end

    x0 = [];
    if nargin >= 9, x0 = varargin{5}; end

    f  = full(f);
    lb = full(lb);
    ub = full(ub);
    x0 = full(x0);

    n = numel(f);
    info = struct();

    xsol = nan(n,1);
    fsol = nan;
    flag = -9;

    if is_mosek
        info.alg = 'mosek';

        [H,f,A,b,Aeq,beq,lb,ub,c] = shift_model(H,f,A,b,Aeq,beq,lb,ub,x0);

        param = struct();
        if use_single_thread_optim
            param.MSK_IPAR_NUM_THREADS = 1; % use a single thread
        end

        prb = struct();
        prb.c = f;
        [prb.qosubi,prb.qosubj,prb.qoval] = find(sparse(tril(H)));
        prb.a = [A; Aeq];
        if isempty(prb.a)
            prb.a = zeros(0,n);
            prb.blc = zeros(0,1);
            prb.buc = zeros(0,1);
        else
            prb.blc = [-inf*ones(size(A,1),1); beq];
            prb.buc = [b; beq];
        end
        if isempty(lb)
            prb.blx = -inf(n,1);
        else
            prb.blx = lb;
        end
        if isempty(ub)
            prb.bux = +inf(n,1);
        else
            prb.bux = ub;
        end

        % rcode: http://docs.mosek.com/6.0/toolbox/node022.html#279719592
        [rcode, res] = mosekopt(['minimize info echo(0)' ...
                                                         ' statuskeys(1) symbcon'], ...
                                prb, param);

        flag = mskeflag(rcode, res);
        info.flag = flag;
        info.rcode = rcode;

        % rcode == 10006 (MSK_RES_TRM_STALL)
        if isfield(res,'sol') && (flag == 1 || rcode == 10006)
            xsol = res.sol.itr.xx;
            fsol = 0.5*(xsol'*H*xsol) + f'*xsol + c;
            if ~isempty(x0)
                xsol = xsol + x0;
            end
            flag = 0;
        else
            % http://docs.mosek.com/7.0/capi/Response_codes.html
            warning(['mosek failed: ' res.rcodestr ...
                                      ' (' num2str(rcode) '), flag: ' num2str(flag)]);
            if 1295 == rcode
                disp(['max(max(H)) = ' num2str(max(max(H)))]);
                disp(['min(eig(H)) = ' num2str(min(eig(H)))]);
            end
            flag = -9;
        end
    else
        info.alg = 'matlab-quadprog';

        options = [];
        options.MaxIter = 1000;
        % http://www.mathworks.com/help/optim/ug/quadprog.html
        [xsol,fsol,flag] = quadprog(H,f,A,b,Aeq,beq,lb,ub,x0,options);
        info.flag = flag;

        if flag == 1
            flag = 0;
        elseif flag == -2
            flag = -1;
        else
            warning(['quadprog flag: ' num2str(flag)]);
            flag = -9;
        end
    end

    if flag == -1
        xsol = nan(length(f));
        fsol = nan;
    end
end

function [H,f,A,b,Aeq,beq,lb,ub,c] = ...
         shift_model(HH,ff,AA,bb,AAeq,bbeq,llb,uub,x0)
    if isempty(x0)
        H = HH;
        f = ff;
        A = AA;
        b = bb;
        Aeq = AAeq;
        beq = bbeq;
        lb = llb;
        ub = uub;
        c = 0;
    else
        H = HH;
        f = ff + HH*x0;
        A = AA;
        b = bb - AA*x0;
        Aeq = AAeq;
        beq = [];
        if ~isempty(bbeq)
            beq = bbeq - AAeq*x0;
        end
        lb = [];
        if ~isempty(llb)
            lb = llb - x0;
        end
        ub = [];
        if ~isempty(uub)
            ub = uub - x0;
        end
        c = 0.5*(x0'*H*x0) + f'*x0;
    end
end
