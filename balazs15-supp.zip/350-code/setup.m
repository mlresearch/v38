
% Define a common library path to search for extensions.
libpath = '/set/to/your/path/to/lib';
if ~exist(libpath)
    warning(['Library path does not exist: ' libpath]);
end

global use_single_thread_optim;
use_single_thread_optim = false;

%------------------------------------------------------------------------------

% MOSEK
global is_mosek;
is_mosek = 0;
path_mosek = [libpath '/mosek'];
path_mosek_lib = [path_mosek '/7/toolbox/r2009b'];
path_mosek_lic = [path_mosek '/mosek.lic'];
if exist(path_mosek)
    if exist(path_mosek_lic)
        try
            setenv('MOSEKLM_LICENSE_FILE', path_mosek_lic);
            addpath(path_mosek_lib);
            prb = struct();
            prb.c = [1;1];
            [prb.qosubi,prb.qosubj,prb.qoval] = find(speye(2));
            prb.a = speye(2);
            prb.blc = [-inf; -inf];
            prb.buc = [2;1];
            rcode = mosekopt(['minimize echo(0) symbcon'], prb);
            if rcode == 0
                is_mosek = 1;
            elseif rcode == 1000
                disp('MOSEK: invalid error (rcode: 1000)');
            elseif rcode == 1001
                disp('MOSEK: license has expired (rcode: 1001)');
            elseif rcode == 1014
                disp('MOSEK: FLEXlm license manager error (rcode: 1014)');
            else
                disp(['MOSEK error (rcode ' num2str(rcode) ')']);
                disp(['See ' ...
                      'http://docs.mosek.com/7.0/capi/Response_codes.html' ...
                      ' for details.']);
            end
            clear prb rcode;
        catch
            lasterror
            lasterror.message
            pause(2);
        end
    else
        warning(['No MOSEK license has found at ' path_mosek_lic '!']);
        pause(2);
    end
end
clear path_mosek path_mosek_lib path_mosek_lic;

