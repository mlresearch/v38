
mex_compile('ma_lse_allcons');
mex_compile('ma_Plse_allcons');
