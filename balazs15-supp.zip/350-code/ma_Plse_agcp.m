
function [model, stat] = ma_Plse_agcp(X, y, B, L, l, u, varargin)
% Finding a (non-lower-truncated) max-affine partitioned LSE
% by the AGCP cutting plane method.
%
% Usage:
%
%    model = ma_Plse_agcp(X, y, B, L, l, u);
%    model = ma_Plse_agcp(X, y, B, L, l, u, options);
%    [model, stat] = ma_Plse_agcp(X, y, B, L, l, u, options);
%
% For prediction on new test data, see:
%
%    help ma_lse_predict
%
% Input:
%
%    X : data points (n x d)
%    y : observations (n x 1)
%    B : range bound for the regression function (1 x 1)
%    L : Lipschitz bound for the regression function (1 x 1)
%    l : lower bounds of the rectangular domain (d x 1)
%    u : upper bounds of the rectangular domain (d x 1)
%
% Output:
%
%    model : max-affine LSE model (fields: B, G, v)
%    stat  : statistics (empty if not collected, see Options: statistics)
%
% Options:
%
%    partition  : partitioning method or partition (default: 'rand-voronoi')
%
%                 'rand-voronoi' : voronoi partition formed by uniformly drawn
%                                  n^(d/(d+4)) centers from the data points X
%                 'kmeans' : find a partition by the k-means algorithm on X
%                            initialized by n^(d/(d+4)) uniformly drawn cells
%                            and run at most 1000 steps
%                 cell array : specify a partition to use
%
%    qpsolver   : quadratic programming solver (default: @qpsolver)
%    redmodtol  : tolerance for dropping redundant hyperplanes (default: 1e-8)
%    tol        : general purpose tolerance value (default: 2^-26)
%    heartbeat  : print dots in each iteration (default: false)
%    statistics : collect statistics (default: false)
%
    if nargin < 6, error('Too few input arguments.'); end
    if nargin > 7, error('Too many input arguments.'); end

    %%% Parse options. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    partition = 'rand-voronoi';
    qp_solver = @qpsolver;
    redmodtol = 1e-8;
    tol = 2^-26; % sqrt(eps)
    heartbeat = false;
    stat = [];
    if nargin == 7
        options = varargin{1};
        if ~isstruct(options), error('Non-struct options.'); end

        if isfield(options, 'partition')
            partition = options.partition;
            if ~iscell(partition) && ...
               ~strcmp(partition, 'rand-voronoi') && ...
               ~strcmp(partition, 'kmeans')
                error('Invalid partition option.');
            end
        end
        if isfield(options, 'qpsolver')
            qp_solver = options.qpsolver;
        end
        if isfield(options, 'redmodtol')
            redmodtol = options.redmodtol;
            if ~isscalar(redmodtol), error('Invalid redmodtol.'); end
        end
        if isfield(options, 'tol')
            tol = options.tol;
            if ~isscalar(tol) || tol < 0, error('Invalid tol.'); end
        end
        if isfield(options, 'heartbeat')
            heartbeat = options.heartbeat;
            if ~islogical(heartbeat), error('Invalid heartbeat.'); end
        end
        if isfield(options, 'statistics')
            if options.statistics, stat = struct(); end
        end
    end

    %%% Check input consistency. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    [n, d] = size(X);
    if d < 1, error('Invalid dimension.'); end
    if n <= 1, error('Too few data points (must n > 1).'); end
    if 1 > min(min(isfinite(X))), error('X should be finite.'); end
    if n ~= size(y,1), error('Row mismatch of X and y.'); end
    if size(y,2) ~= 1, error('y should be one dimensional.'); end
    if 1 > min(isfinite(y)), error('y should be finite.'); end
    if d ~= numel(l)
        if 1 == numel(l), l = l*ones(1,d);
        else error('Invalid dimension for l.'); end
    else
        if 1 == size(l,2), l = l'; end
    end
    if 1 > min(isfinite(l)), error('l should be finite.'); end
    if d ~= numel(u)
        if 1 == numel(u), u = u*ones(1,d);
        else error('Invalid dimension for u.'); end
    else
        if 1 == size(u,2), u = u'; end
    end
    if 1 > min(isfinite(u)), error('u should be finite.'); end
    if min(u-l) <= 0, error('(l < u) should hold.'); end
    if ~isscalar(B), error('B should be a scalar.'); end
    if B <= 0, error('B should be positive.'); end
    if ~isscalar(L), error('L should be a scalar.'); end
    if L <= 0, error('L should be positive.'); end

    %%% Initialize statistics. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if ~isempty(stat)
        time_start = tic;
    end

    %%% Initialize partition. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    P = {};
    K = ceil(n^(d/(d+4)));
    if strcmp(partition, 'rand-voronoi')
        P = P_rand_voronoi(X, K);
    elseif strcmp(partition, 'kmeans')
        [P, niter] = P_kmeans(X, K, 1000, tol);
        if ~isempty(stat)
            stat.niter_kmeans = niter;
        end
        clear niter;
    else
        P = P_check(partition, n);
    end
    K = numel(P);

    % Cell centers.
    Xbar = cell2mat(cellfun(@(cell) mean(X(cell,:),1), P, 'uni', false)');

    %%% Build objective and all constraint data. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if ~isempty(stat)
        stat.time_Pinit = toc(time_start);
    end

    d2 = d*2;
    Kd2 = K*d2;

    % variable layout: [v; G], G = [g^+; g^-]^K
    % size: K*(1+2*d) x 1
    % v : (K x 1), hyperplane heights
    % G : (2*d x K)(:), hyperplane slopes
    nvars = K+Kd2;

    H = sparse(nvars, nvars);
    f = zeros(nvars, 1);
    for k = 1:K
        cell = P{k};

        Xk = bsxfun(@minus, X(cell,:), Xbar(k,:));
        X1 = [ones(size(Xk,1),1), Xk, -Xk];
        r = K + (k-1)*d2 + [1:d2];

        XX = X1'*X1;
        XX1 = XX(2:end,1);

        H(k,k) = XX(1,1);
        H(r,k) = XX1;
        H(k,r) = XX1';
        H(r,r) = XX(2:end,2:end);

        Xy = -X1'*y(cell);
        f(k) = Xy(1);
        f(r) = Xy(2:end);
    end
    H = H + tol*speye(nvars); % numerical stabilization
    clear XX XX1 Xy Xk X1 r cell;

    % v_k + g_k'*(X_i - Xbar_k) >= v_l + g_l'*(X_i - Xbar_l)
    % [Ant, bn, Pcounts] = ma_Plse_allcons_slow(X, P, Xbar);
    [Ant, bn, Pcounts] = ma_Plse_allcons(X, P, Xbar);

    % max_x fn(x) <= B  s.t. x \in [l,u]
    Ab = sparse(K, K+Kd2);
    pos = K;
    for k = 1:K
        r = pos + [1:d];
        Ab(k,k) = 1;               % * v_k
        Ab(k,r) = u - Xbar(k,:);   % * (g_k^+)'
        Ab(k,r+d) = Xbar(k,:) - l; % * (g_k^-)'
        pos = pos + d2;
    end
    bb = B*ones(size(Ab,1), 1);
    clear r pos;

    % -B <= v <= B, g_k = g_k^+ - g_k^-, 0 <= g_k^+, g_k^- <= L
    BonesK = B*ones(K,1);
    lb = [-BonesK; zeros(Kd2, 1)];
    ub = [ BonesK; L*ones(Kd2, 1)];
    clear Kd2 BonesK;

    %%% Build cache data. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    grp = {};
    Ac = [];
    bc = [];
    Pmap = cumsum(Pcounts);
    Pmap = [0; Pmap(1:end-1)];
    for k = 1:K
        % find a group for k-th center Xbar(k,:)
        group = [];
        diffs = bsxfun(@minus, Xbar, Xbar(k,:));
        for j = 1:d
            gts = find(diffs(:,j) > tol);
            if ~isempty(gts)
                [~,gt] = min(diffs(gts,j));
                group = union(group, gts(gt));
            end

            les = find(diffs(:,j) < -tol);
            if ~isempty(les)
                [~,le] = max(diffs(les,j));
                group = union(group, les(le));
            end
        end
        grp{k} = group;

        idx = Pmap(k) + group;
        Agi = sum(Ant(:,idx), 2);
        bgi = sum(bn(idx), 1);

        Ac = [Ac, Agi];
        bc = [bc; bgi];
    end
    clear Pmap group Agi bgi;

    %%% Solving the problem. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if ~isempty(stat)
        stat.time_init = toc(time_start);
        time_train = tic;

        stat.niter = 0;
        stat.qp_flags = [];
        stat.time_qp = 0;
    end

    x = zeros(nvars, 1); % initial point

    usedn = [];    % indices of used (non-boundary) constraints
    usedb = false; % usage of (boundary) constraints

    if heartbeat, fprintf(1, '     '); end
    while true
        if heartbeat, fprintf(1, '.'); end
        if ~isempty(stat), stat.niter = stat.niter + 1; end

        % Solve the quadratic program (QP).
        if usedb
            A = [Ac'; Ab];
            b = [bc; bb];
        else
            A = Ac';
            b = bc;
        end
        if ~isempty(stat), time_qp_start = tic; end
        [x, obj, flag] = qp_solver(H, f, A, b, [], [], lb, ub, x);
        if ~isempty(stat)
            stat.time_qp = stat.time_qp + toc(time_qp_start);
            clear time_qp_start;
            stat.qp_flags = [stat.qp_flags, flag];
        end

        % Check constraint violations.
        gaps = Ant'*x - bn;
        iviol = find(gaps > tol);
        iviol = setdiff(iviol, usedn); % (invariance safety)
        if isempty(iviol)
            if usedb, break; end

            gapsb = Ab*x - bb;
            iviolb = find(gapsb > tol);
            clear gapsb;
            if isempty(iviolb), break; end
            clear iviolb;

            % Use all boundary constraints.
            usedb = true;
        else
            % Update non-boundary constraints.
            r = 0;
            for k = 1:K
                rnext = r + Pcounts(k);

                iviolki = find(iviol <= rnext);
                if ~isempty(iviolki)
                    iviolk = iviol(iviolki);
                    iviol(iviolki) = [];

                    % index of most violated constraint
                    [~,maxk] = max(gaps(iviolk));
                    maxk = iviolk(maxk);

                    % the most violated constraint
                    Ank = Ant(:,maxk);
                    bnk = bn(maxk);

                    % remove most violated constraint from aggregation
                    if ~isempty(find(grp{k} == maxk))
                        Ac(:,k) = Ac(:,k) - Ank;
                        bc(k) = bc(k) - bnk;
                        grp{k} = setdiff(grp{k}, maxk);
                        if 0 == numel(grp{k})
                            % Clear the aggregate constraint.
                            Ac(:,k) = 0;
                            bc(k) = 0;
                        end
                    end

                    % add most violated constraint to cache
                    usedn = [usedn; maxk];
                    Ac = [Ac, Ank];
                    bc = [bc; bnk];
                end

                r = rnext;
            end
        end
    end
    if heartbeat, fprintf(1, '\n'); end

    %%% Format the output. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if ~isempty(stat)
        stat.time_train = toc(time_train);
        clear time_train;
    end

    v = x(1:K);
    G = reshape(x(K+1:end), d2, K)';
    G = G(:,1:d) - G(:,d+1:end); % g_k = (g_k^+) - (g_k^-)

    model = struct();
    model.B = B;
    model.G = G;
    model.v = v - sum(G .* Xbar, 2);

    % Drop redundant planes.
    if redmodtol >= 0
        model = ma_lse_redmod(model, X, redmodtol);
    end

    if ~isempty(stat)
        stat.model_size = numel(model.v);
        stat.time_total = toc(time_start);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [At, b, Pcounts] = ma_Plse_allcons_slow(X, P, Xbar)
% This is the slow version for testing purposes.
% Use the fast one instead given in ma_Plse_allcons.c.
%
    [n,d] = size(X);
    K = numel(P);

    d2 = d*2;
    ncols = K*(1+d2);
    A = sparse(0, ncols);
    Pcounts = zeros(K, 1);

    q = 1;
    for l = 1:K
        rl = K + (l-1)*d2 + [1:d];

        for k = 1:K
            if k == l, continue; end

            cell = P{k};
            rk = K + (k-1)*d2 + [1:d];
            Pcounts(l) = Pcounts(l) + numel(cell);
            for j = 1:numel(cell)
                Xj = X(cell(j),:);

                row = sparse(1,ncols);
                row(l) =  1;                % * v_l
                row(1,rl) = Xj - Xbar(l,:); % * (g_l^+)'
                row(1,rl+d) = -row(rl);     % * (g_l^-)'

                row(k) = -1;                % * v_k
                row(1,rk) = Xbar(k,:) - Xj; % * (g_k^+)'
                row(1,rk+d) = -row(rk);     % * (g_k^-)'

                A(q,:) = row;
                q = q + 1;
            end
        end
    end

    At = A';
    b = sparse(size(A,1), 1);
end
