
function [model, stat] = ma_lse_agcp(X, y, B, L, l, u, varargin)
% Finding a (non-lower-truncated) max-affine LSE
% by the AGCP cutting plane method.
%
% Usage:
%
%    model = ma_lse_agcp(X, y, B, L, l, u);
%    model = ma_lse_agcp(X, y, B, L, l, u, options);
%    [model, stat] = ma_lse_agcp(X, y, B, L, l, u, options);
%
% For prediction on new test data, see:
%
%    help ma_lse_predict
%
% Input:
%
%    X : data points (n x d)
%    y : observations (n x 1)
%    B : range bound for the regression function (1 x 1)
%    L : Lipschitz bound for the regression function (1 x 1)
%    l : lower bounds of the rectangular domain (d x 1)
%    u : upper bounds of the rectangular domain (d x 1)
%
% Output:
%
%    model : max-affine LSE model (fields: B, G, v)
%    stat  : statistics (empty if not collected, see Options: statistics)
%
% Options:
%
%    qpsolver   : quadratic programming solver (default: @qpsolver)
%    redmodtol  : tolerance for dropping redundant hyperplanes (default: 1e-8)
%    tol        : general purpose tolerance value (default: 2^-26)
%    heartbeat  : print dots in each iteration (default: false)
%    statistics : collect statistics (default: false)
%
    if nargin < 6, error('Too few input arguments.'); end
    if nargin > 7, error('Too many input arguments.'); end

    %%% Parse options. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    qp_solver = @qpsolver;
    redmodtol = 1e-8;
    tol = 2^-26; % sqrt(eps)
    heartbeat = false;
    stat = [];
    if nargin == 7
        options = varargin{1};
        if ~isstruct(options), error('Non-struct options.'); end

        if isfield(options, 'qpsolver')
            qp_solver = options.qpsolver;
        end
        if isfield(options, 'redmodtol')
            redmodtol = options.redmodtol;
            if ~isscalar(redmodtol), error('Invalid redmodtol.'); end
        end
        if isfield(options, 'tol')
            tol = options.tol;
            if ~isscalar(tol) || tol < 0, error('Invalid tol.'); end
        end
        if isfield(options, 'heartbeat')
            heartbeat = options.heartbeat;
            if ~islogical(heartbeat), error('Invalid heartbeat.'); end
        end
        if isfield(options, 'statistics')
            if options.statistics, stat = struct(); end
        end
    end

    %%% Check input consistency. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    [n, d] = size(X);
    if d < 1, error('Invalid dimension.'); end
    if n <= 1, error('Too few data points (must n > 1).'); end
    if 1 > min(min(isfinite(X))), error('X should be finite.'); end
    if n ~= size(y,1), error('Row mismatch of X and y.'); end
    if size(y,2) ~= 1, error('y should be one dimensional.'); end
    if 1 > min(isfinite(y)), error('y should be finite.'); end
    if d ~= numel(l)
        if 1 == numel(l), l = l*ones(1,d);
        else error('Invalid dimension for l.'); end
    else
        if 1 == size(l,2), l = l'; end
    end
    if 1 > min(isfinite(l)), error('l should be finite.'); end
    if d ~= numel(u)
        if 1 == numel(u), u = u*ones(1,d);
        else error('Invalid dimension for u.'); end
    else
        if 1 == size(u,2), u = u'; end
    end
    if 1 > min(isfinite(u)), error('u should be finite.'); end
    if min(u-l) <= 0, error('(l < u) should hold.'); end
    if ~isscalar(B), error('B should be a scalar.'); end
    if ~isfinite(B), error('B should be finite.'); end
    if B <= 0, error('B should be positive.'); end
    if ~isscalar(L), error('L should be a scalar.'); end
    if ~isfinite(L), error('L should be finite.'); end
    if L <= 0, error('L should be positive.'); end

    %%% Initialize statistics. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if ~isempty(stat)
        time_start = tic;
    end

    %%% Build objective and all constraint data. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % variable layout: [v; G], G = [g^+; g^-]^n
    % size: n*(1+2*d) x 1
    % v : (n x 1), hyperplane heights
    % G : (2*d x n)(:), hyperplane slopes

    d2 = d*2;
    nd2 = n*d2;
    H = blkdiag(speye(n), sparse(nd2, nd2));
    f = [-y; zeros(nd2, 1)];

    % y_i - y_k + g_i'*(X_k - X_i) <= 0
    % [Ant, bn] = ma_lse_allcons_slow(X);
    [Ant, bn] = ma_lse_allcons(X);

    % max_x fn(x) <= B  s.t. x \in [l,u]
    Ab = sparse(n, n+nd2);
    pos = n;
    for i = 1:n
        r = pos + [1:d];
        Ab(i,i) = 1;            % * y_i
        Ab(i,r) = u - X(i,:);   % * (g_i^+)'
        Ab(i,r+d) = X(i,:) - l; % * (g_i^-)'
        pos = pos + d2;
    end
    bb = B*ones(size(Ab,1), 1);
    clear r pos;

    % -B <= y <= B, g_i = g_i^+ - g_i^-, 0 <= g_i^+, g_i^- <= L
    Bonesn = B*ones(n,1);
    lb = [-Bonesn; zeros(nd2, 1)];
    ub = [ Bonesn; L*ones(nd2, 1)];
    clear nd2 Bonesn;

    %%% Build cache data. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    grp = {};
    Ac = [];
    bc = [];
    r = 0;
    n1 = n - 1;
    for i = 1:n
        rn1 = r + n1;

        % find a group for Xi
        group = [];
        diffs = bsxfun(@minus, X, X(i,:));
        for j = 1:d
            gts = find(diffs(:,j) > tol);
            if ~isempty(gts)
                [~,gt] = min(diffs(gts,j));
                group = union(group, gts(gt));
            end

            les = find(diffs(:,j) < -tol);
            if ~isempty(les)
                [~,le] = max(diffs(les,j));
                group = union(group, les(le));
            end
        end
        grp{i} = group;

        idx = r + group;
        Agi = sum(Ant(:,idx), 2);
        bgi = sum(bn(idx), 1);

        Ac = [Ac, Agi];
        bc = [bc; bgi];

        r = rn1;
    end

    %%% Solving the problem. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if ~isempty(stat)
        stat.time_init = toc(time_start);
        time_train = tic;

        stat.niter = 0;
        stat.qp_flags = [];
        stat.time_qp = 0;
    end

    x = zeros(numel(f), 1); % initial point

    usedn = [];    % indices of used (non-boundary) constraints
    usedb = false; % usage of (boundary) constraints

    if heartbeat, fprintf(1, '     '); end
    while true
        if heartbeat, fprintf(1, '.'); end
        if ~isempty(stat), stat.niter = stat.niter + 1; end

        % Solve the quadratic program (QP).
        if usedb
            A = [Ac'; Ab];
            b = [bc; bb];
        else
            A = Ac';
            b = bc;
        end
        if ~isempty(stat), time_qp_start = tic; end
        [x, obj, flag] = qp_solver(H, f, A, b, [], [], lb, ub, x);
        if ~isempty(stat)
            stat.time_qp = stat.time_qp + toc(time_qp_start);
            clear time_qp_start;
            stat.qp_flags = [stat.qp_flags, flag];
        end

        % Check constraint violations.
        gaps = Ant'*x - bn;
        iviol = find(gaps > tol);
        iviol = setdiff(iviol, usedn); % (invariance safety)
        if isempty(iviol)
            if usedb, break; end

            gapsb = Ab*x - bb;
            iviolb = find(gapsb > tol);
            clear gapsb;
            if isempty(iviolb), break; end
            clear iviolb;

            % Use all boundary constraints.
            usedb = true;
        else
            % Update non-boundary constraints.
            inds = ceil(iviol / n1);
            for i = 1:n
                ivioli = iviol(find(inds == i));
                if ~isempty(ivioli)
                    % Index of most violated constraint of point i.
                    [~,maxi] = max(gaps(ivioli));
                    maxi = ivioli(maxi);

                    % The most violated constraint.
                    Ani = Ant(:,maxi);
                    bni = bn(maxi);

                    % Remove most violated constraint from aggregation.
                    if ~isempty(find(grp{i} == maxi))
                        Ac(:,i) = Ac(:,i) - Ani;
                        bc(i) = bc(i) - bni;
                        grp{i} = setdiff(grp{i}, maxi);
                        if 0 == numel(grp{i})
                            % Clear the aggregate constraint.
                            Ac(:,i) = 0;
                            bc(i) = 0;
                        end
                    end

                    % Add the most violated constraint to cache.
                    usedn = [usedn; maxi];
                    Ac = [Ac, Ani];
                    bc = [bc; bni];
                end
            end
        end
    end
    if heartbeat, fprintf(1, '\n'); end

    %%% Format the output. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if ~isempty(stat)
        stat.time_train = toc(time_train);
        clear time_train;
    end

    haty = x(1:n);
    G = reshape(x(n+1:end), d2, n)';
    G = G(:,1:d) - G(:,d+1:end); % g_i = (g_i^+) - (g_i^-)

    model = struct();
    model.B = B;
    model.G = G;
    model.v = haty - sum(G .* X, 2);

    % Drop redundant planes.
    if redmodtol >= 0
        model = ma_lse_redmod(model, X, redmodtol);
    end

    if ~isempty(stat)
        stat.model_size = numel(model.v);
        stat.time_total = toc(time_start);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [At, b] = ma_lse_allcons_slow(X)
% This is the slow version for testing purposes.
% Use the fast one instead given in ma_lse_allcons.c.
%
    [n,d] = size(X);

    d2 = d*2;
    A = sparse(n*(n-1), n*(1+d2));

    q = 1;
    for i = 1:n
        r = n + (i-1)*d2 + [1:d];
        for k = 1:n
            if k == i, continue; end

            A(q,i) =  1;              % * y_i
            A(q,k) = -1;              % * y_k
            A(q,r) = X(k,:) - X(i,:); % * (g_i^+)'
            A(q,r+d) = -A(q,r);       % * (g_i^-)' 
            q = q+1;
        end
    end

    At = A';
    b = sparse(size(A,1), 1);
end
