
function P = P_check(P, n, varargin)
% Checks the consistency of partition P.
%
    if ~iscell(P), error('P is not a partition.'); end

    K = numel(P);
    if nargin >= 3
        Kreq = varargin{1};
        if K ~= Kreq
            error(['Inconsistent number of partitions: ' ...
                   num2str(K) ' ~= ' num2str(Kreq) '.']);
        end
        K = Kreq;
    end

    ind = zeros(n,1);
    K = numel(P);
    for k = 1:K
        cell = P{k};

        if isempty(cell)
            error(['Cell ' num2str(k) ' is empty.']);
        end
        if numel(cell) > 1 && size(cell,1) == 1
            P{k} = P{k}'; % Flip the cell to column vector.
        end

        ind(cell) = ind(cell) + 1;
    end

    i = find(ind == 0);
    if ~isempty(i)
        error(['Point ' num2str(i(1)) ' is not in any cell.']);
    end

    i = find(ind > 1);
    if ~isempty(i)
        error(['Point ' num2str(i(1)) ' is in multiple cells.']);
    end
end
