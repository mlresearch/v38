
function [P, niter] = P_kmeans(X, K, maxiter, tol)
% Returns a partition P of data points X by the k-means algorithm
% initialized by uniformly drawn K centers and run at most maxiter iterations.
%
    [n,d] = size(X);

    inds = randperm(n);
    inds = inds(1:K);
    C = X(inds,:);
    P = {};

    for niter = 1:maxiter
        % assignment step
        Pnew = P_voronoi(C, X);
        % update step
        Cnew = zeros(K,d);
        for i = 1:K
            if isempty(Pnew{i})
                Cnew(i,:) = X(randi(n),:);
            else
                Cnew(i,:) = mean(X(Pnew{i},:));
            end
        end
        % exit if converged
        if sum(sum(abs(C-Cnew))) / numel(C) < tol, break; end
        P = Pnew;
        C = Cnew;
    end
end
