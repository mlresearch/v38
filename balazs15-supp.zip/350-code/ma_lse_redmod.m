
function rmodel = ma_lse_redmod(model, X, varargin)
% Dropping redundant hyperplanes of max-affine LSE models.
%
% Usage:
%
%    rmodel = ma_lse_redmod(model, X);
%    rmodel = ma_lse_redmod(model, X, tol);
%
% Input :
%
%    model : max-affine LSE model (fields: B, G, v)
%    X     : training data points (n x d)
%    tol   : tolerance (default: 1e-8)
%
    if nargin > 3, error('Too many input arguments.'); end

    [n,d] = size(X);
    if n < 1 || d < 1, error('Invalid X.'); end
    if ~isfield(model, 'v'), error('Missing model.v.'); end
    if ~isfield(model, 'G'), error('Missing model.G.'); end
    if size(model.G,1) ~= numel(model.v), error('Inconsistent model.'); end
    if d ~= size(model.G,2), error('Invalid size(X,2).'); end

    tol = 1e-8;
    if nargin == 3, tol = varargin{1}; end
    if ~isscalar(tol) || tol < 0, error('Invalid tol.'); end

    B = [];
    if isfield(model, 'B')
        if ~isscalar(model.B), error('Invalid model.B.'); end
        B = model.B;
    end

    G = model.G;
    v = model.v;
    y = ma_eval(B, G, v, X);

    idx = 1;
    K = numel(v);
    for i = 1:K
        if numel(v) == 1, break; end

        Gt = G; Gt(idx,:) = [];
        vt = v; vt(idx) = [];

        yt = ma_eval(B, Gt, vt, X);
        err = sqrt(sum((yt-y).^2 / n));
        if err <= tol
            % Drop the hyperplane.
            G = Gt;
            v = vt;
        else
            idx = idx + 1;
        end
    end

    rmodel = model;
    rmodel.G = G;
    rmodel.v = v;
end

function y = ma_eval(B, G, v, X)
    y = max(bsxfun(@plus, G*X', v))';
    if ~isempty(B), y = max(-B, y); end
end
