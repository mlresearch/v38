if ~exist('is_mosek', 'var'), setup; end

%%% Problem setup. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

d     =   4; % domain dimension
b     =   2; % domain sup-norm radius
n     = 128; % number of training samples
B     =   8; % range
sigma =   1; % noise standard deviation

% regression function (half quadratic problem)
fstar = @(X) sum((max(0,X)/b).^2, 2) * (2*B/d) - B;

% squared loss
loss = @(yhat,y) sqrt(sum((yhat-y).^2 / length(y)));

% upper bound on the Lipschitz constant
L = 4*B / (d*b);

%%% Training. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% training data (uniform data points and Gaussian noise)
X = (2*rand(n,d)-1) * b;
y = fstar(X) + (randn(n,1) * sigma);

% train LSE
model_lse = ma_lse_agcp(X, y, B, L, -b, b);
train_risk_lse = loss(ma_lse_predict(model_lse,X), y);

% train PLSE
model_Plse = ma_Plse_agcp(X, y, B, L, -b, b);
train_risk_Plse = loss(ma_lse_predict(model_Plse,X), y);

%%% Testing. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% test data
n_test = 1000000; % number of test samples
X_test = (2*rand(n_test,d)-1) * b;
y_test = fstar(X_test);

% test errors
test_err_lse = loss(ma_lse_predict(model_lse,X_test), y_test);
test_err_Plse = loss(ma_lse_predict(model_Plse,X_test), y_test);

%%% Reporting. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

K = ceil(n^(d/(d+4)));

disp(' ');
disp(['LSE (n = ' num2str(n) ')']);
disp(['  training L2 risk : ' num2str(train_risk_lse)]);
disp(['  test L2 error    : ' num2str(test_err_lse)]);
disp(['  # of hyperplanes : ' num2str(numel(model_lse.v))]);
disp(' ');
disp(['PLSE (K = ' num2str(K) ')']);
disp(['  training L2 risk : ' num2str(train_risk_Plse)]);
disp(['  test L2 error    : ' num2str(test_err_Plse)]);
disp(['  # of hyperplanes : ' num2str(numel(model_Plse.v))]);
disp(' ');
