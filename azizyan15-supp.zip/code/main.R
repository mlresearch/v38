# Execute this script to run the tests and reproduce each plot.
# Results may not be identical, since the EM algorithm
#  is random.
# Requires packages linprog, EMCluster, and mvtnorm.
# Set the following flag to false to rerun all code, instead
#  of using saved intermediate results (takes a bit of time):
useSaved <- TRUE

# fs.R defines the algorithm and some helper functions:
source("fs.R")

range2 <- function(z) range(range(z),-range(z))

#####################################################
# Plot test1 results:

lambdalst <- seq(0.001,1,length=10)
if(!useSaved) {
  source("test1.R")
} else {
  load("savedata_2dstacked")
  s <- 2
  ds <- nrow(l.embetas)-s
}

pdf("plot_2dstacked_em.pdf")
par(mar=c(4, 6.5, 1, 0) + 0.1)
plot(c(),c(),xlim=range(lambdalst),ylim=range2(l.embetas), 
  xlab=expression(lambda),ylab=expression(widehat(beta)[lambda]),
  cex.lab=3,cex.axis=2,yaxt='n')
axis(2,cex.axis=2.3)
legend(0.4,1,cex=2,legend=c("rel. features","irrel. features"), 
#  col=c(1,8),lty=c(2,1),lwd=5)
  col=c(1,8),lty=c(1,1),lwd=5)
for(i in s+(1:ds)) lines(lambdalst,l.embetas[i,],lwd=3,col=8,lty=1)
for(i in 1:s) lines(lambdalst,l.embetas[i,],lwd=3,col=1,lty=1)
#for(i in 1:s) lines(lambdalst,l.embetas[i,],lwd=7,col=1,lty=2)
dev.off()

pdf("plot_2dstacked_hp.pdf")
par(mar=c(4, 6.5, 1, 0) + 0.1)
plot(c(),c(),xlim=range(lambdalst),ylim=range2(l.hpbetas), 
  xlab=expression(lambda),ylab=expression(widehat(beta)[lambda]),
  cex.lab=3,cex.axis=2,yaxt='n')
axis(2,cex.axis=2.3)
for(i in s+(1:ds)) lines(lambdalst,l.hpbetas[i,],lwd=3,col=8,lty=1)
for(i in 1:s) lines(lambdalst,l.hpbetas[i,],lwd=3,col=1,lty=1)
#for(i in 1:s) lines(lambdalst,l.hpbetas[i,],lwd=7,col=1,lty=2)
dev.off()

#####################################################
# Plot test2 results:

lambdalst <- seq(0.001,1,length=10)
if(!useSaved) {
  source("test2.R")
} else {
  load("savedata_nonspherical1_s=5")
  s <- 5
  ds <- nrow(l.hpbetas)-s
}

pdf("plot_nonspherical_hp_s=5.pdf")
par(mar=c(4, 6.5, 1, 0) + 0.1)
plot(c(),c(),xlim=range(lambdalst),ylim=range2(l.hpbetas), 
  xlab=expression(lambda),ylab=expression(widehat(beta)[lambda]), 
  cex.lab=3,cex.axis=2,yaxt='n')
axis(2,cex.axis=2.3)
for(i in s+(1:ds)) lines(lambdalst,l.hpbetas[i,],lwd=3,col=8,lty=1)
for(i in 1:s) lines(lambdalst,l.hpbetas[i,],lwd=3,lty=1)
#for(i in 1:s) lines(lambdalst,l.hpbetas[i,],lwd=7,lty=2)
dev.off()

#####################################################
# Plot test3 results:

lambdalst2 <- seq(0.5,5,length=15)
if(!useSaved) {
  source("test3.R")
} else {
  load("savedata_nonspherical2_s=5")
  s <- 5
  ds <- nrow(l.hpbetas)-s
}

pdf("plot_nonspherical2_hp_s=5.pdf")
par(mar=c(4, 6.5, 1, 0) + 0.1)
plot(c(),c(),xlim=range(lambdalst2),ylim=range2(l.hpbetas), 
  xlab=expression(lambda),ylab=expression(widehat(beta)[lambda]), 
  cex.lab=3,cex.axis=2,yaxt='n')
axis(2,cex.axis=2.3)
for(i in s+(1:ds)) lines(lambdalst2,l.hpbetas[i,],lwd=3,col=8,lty=1)
for(i in 1:s) lines(lambdalst2,l.hpbetas[i,],lwd=3,lty=1)
#for(i in 1:s) lines(lambdalst2,l.hpbetas[i,],lwd=7,lty=2)
dev.off()



