require(linprog)
require(EMCluster)
require(mvtnorm)

# Given data matrix X (with columns=features, rows=observations),
#  executing f.hp.fullcov(X, pivot=f.find.pivot(X)$best.ind) should
#  return a list with elements pi, Mu, S1, and S2, containing the
#  estimated mixture component weights, means, and covariances.


#####################################################
# hardt and price algorithm with known univariate pivot
# there are three steps:
# 1) learn parameters for X[,pivot]
# 2) learn all parameters EXCEPT elements of the covariance
#  with indices (i,j) where i!=pivot and j!=pivot, using 
#  bivariate X[,c(pivot,i)]
# 3) learn elements of the covariance not learned in the 
#  previous step using trivariate marginals X[,c(pivot,i,j)]
f.hp.fullcov <- function(X, pivot, verbose=TRUE) {
  d <- ncol(X)
  mu <- matrix(NA,2,d)
  S1 <- matrix(NA,d,d)
  S2 <- matrix(NA,d,d)
  # step 1: learn pivot parameters
  tmpX <- X[,pivot,drop=FALSE]
  tmpemc <- emcluster(tmpX, init.EM(tmpX, nclass=2))
  pi <- tmpemc$pi
  if(tmpemc$nclass==1) {
  cat("ERROR (f.hp.fullcov): mixture not found in pivot marginal\n")
  return(NULL)
  }
  if(verbose) cat("pivot weights:",pi,"\n")
  mu[,pivot] <- tmpemc$Mu
  S1[pivot,pivot] <- tmpemc$LTSigma[1,]
  S2[pivot,pivot] <- tmpemc$LTSigma[2,]
  # step 2: learn means and elements of the covariance involving pivot
  if(verbose) cat("bivariate stage\n")
  for(i in setdiff(1:d, pivot)) {
    if(verbose) cat(i,"/",d,"\n")
    tmpX <- X[,c(pivot,i)]
    tmpemc <- emcluster(tmpX, init.EM(tmpX, nclass=2))
    if(tmpemc$nclass<2) {
      cat("ERROR: nclass<2; i ==",i,"\n")
      return(NULL)
    }
    mu[,i] <- tmpemc$Mu[,2]
    S1[i,pivot] <- S1[pivot,i] <- tmpemc$LTSigma[1,2]
    S2[i,pivot] <- S2[pivot,i] <- tmpemc$LTSigma[2,2]
    S1[i,i] <- tmpemc$LTSigma[1,3]
    S2[i,i] <- tmpemc$LTSigma[2,3]
    # this if statement applies the pivot idea, i.e. it checks whether
    # the order of parameters learned for X[,c(pivot,i)] agrees with
    # the order of parameters learned for the pivot itself
    if(max(abs(mu[,pivot]-tmpemc$Mu[,1]))>max(abs(mu[,pivot]-tmpemc$Mu[2:1,1]))) {
      mu[,i] <- tmpemc$Mu[2:1,2]
      S1[i,pivot] <- S1[pivot,i] <- tmpemc$LTSigma[2,2]
      S2[i,pivot] <- S2[pivot,i] <- tmpemc$LTSigma[1,2]
      S1[i,i] <- tmpemc$LTSigma[2,3]
      S2[i,i] <- tmpemc$LTSigma[1,3]
    }
  }
  # step 3: learn elements of the covariance not involving pivot
  if(d>2) {
    if(verbose) cat("trivariate stage\n")
    for(i in setdiff(1:(d-1), pivot)) {
      if(verbose) cat(i,"/",d,"\n")
      for(j in setdiff((i+1):d, pivot)) {
        tmpX <- X[,c(pivot,i,j)]
        tmpemc <- emcluster(tmpX, init.EM(tmpX, nclass=2))
        if(tmpemc$nclass<2) {
          cat("ERROR: nclass<2; i ==",i,"\n")
          return(NULL)
        }
        #(1,1),(1,2),(2,2),(1,3),(2,3),(3,3)
        S1[i,j] <- S1[j,i] <- tmpemc$LTSigma[1,5]
        S2[i,j] <- S2[j,i] <- tmpemc$LTSigma[2,5]
        # this if statement applies the pivot idea
        if(max(abs(mu[,pivot]-tmpemc$Mu[,1]))>max(abs(mu[,pivot]-tmpemc$Mu[2:1,1]))) {
          S1[i,j] <- S1[j,i] <- tmpemc$LTSigma[2,5]
          S2[i,j] <- S2[j,i] <- tmpemc$LTSigma[1,5]
        }
      }
    }
  }
  return(list(pi=pi,Mu=mu,S1=S1,S2=S2))
}


#####################################################
# choose pivot
f.find.pivot <- function(X,verbose=TRUE) {
  d <- ncol(X)
  mumat <- matrix(0,2,d)
  pimat <- matrix(0,2,d)
  sigmat <- matrix(0,2,d)
  for(i in 1:d) {
    if(verbose) cat(i,"/",d,"\n")
    tmpX <- X[,i,drop=FALSE]
    tmpemc <- emcluster(tmpX, init.EM(tmpX, nclass=2))
    mumat[1,i] <- tmpemc$Mu[1,1]
    pimat[1,i] <- tmpemc$pi[1]
    sigmat[1,i] <- tmpemc$LTSigma[1,1]
    if(tmpemc$nclass>1) {
    mumat[2,i] <- tmpemc$Mu[2,1]
    pimat[2,i] <- tmpemc$pi[2]
    sigmat[2,i] <- tmpemc$LTSigma[2,1]
    }
  }
  if(any(abs(colSums(pimat)-1)>1e-8)) cat("WARNING (f.find.pivot): pi don't sum to 1\n")
  heuristic.scores <- sqrt(pimat[1,]*pimat[2,])*abs(mumat[1,]-mumat[2,])/sqrt(sigmat[1,]+sigmat[2,])
  return(list(best.ind=which.max(heuristic.scores),scores=heuristic.scores, 
	  mumat=mumat,pimat=pimat,sigmat=sigmat))
}


#####################################################
# sample from mixture of 2 normals
# gmpar=list(n1,n2,Mu,S1,S2) where dim(Mu) is c(2,ncol(S1))
# returns list with elemens X (dim(X) is c(n1+n2,ncol(Mu))), gmpar, seed, 
# and cls which indicates mixture component membership
f.r.gmmix2 <- function(gmpar,seed=NULL) {
  set.seed(seed)
  temp1 <- with(gmpar,rmvnorm(n1,Mu[1,],S1))
  temp2 <- with(gmpar,rmvnorm(n2,Mu[2,],S2))
  set.seed(NULL)
  temp3 <- rbind(temp1,temp2)
  return(list(X=temp3,cls=c(rep(1,gmpar$n1),rep(2,gmpar$n2)),gmpar=gmpar,seed=seed))
}


#####################################################
# solves beta = argmin_z ||z||_1 st ||S z - delta||_inf<=lambda
# returns list containing LP solution details (see ?solveLP), and
# optimal beta
f.solvecai <- function(A,u,lambda) {
  d <- ncol(A)
  cvec <- rep(1,2*d)
  bvec <- lambda + c(u,-u)
  Amat <- rbind(cbind(A,-A),cbind(-A,A))
  templs <- solveLP(cvec, bvec, Amat)
  zh <- as.vector(templs$solution)
  return(c(templs,list(beta=zh[1:d]-zh[d+(1:d)])))
}

#####################################################
# translates from long form specification of multiple covariances (as
# returned by EMCluster::emcluster) to a list of covariance matrices
f.sig.longtolist <- function(LTSigma) {
  nc <- nrow(LTSigma)
  d <- (sqrt(1+8*ncol(LTSigma))-1)/2
  covl <- list()
  utm.wd <- upper.tri(matrix(0,d,d),T)
  utm <- upper.tri(matrix(0,d,d))
  for(i in 1:nc) {
    tcov <- matrix(0,d,d)
    tcov[utm.wd] <- LTSigma[i,]
    tcov <- tcov+t(tcov*utm)
    covl <- c(covl,list(tcov))
  }
  return(list(nc=nc,sigs=covl))
}



#####################################################
# generates well-conditioned random covariance matrix
f.rwishart <- function(d,n=2*d,seed=31415,Smin=0.5,Smax=2,rescale=TRUE) {
  set.seed(seed)
  temp <- matrix(rnorm(d*n),d,n)
  set.seed(NULL)
  temp2 <- temp%*%t(temp)
  if(!rescale) return(temp2/n)
  temp3 <- eigen(temp2,symmetric=TRUE)
  temp4 <- range(temp3$values)
  temp5 <- (temp3$values-temp4[1])*(Smax-Smin)/(temp4[2]-temp4[1])+Smin
  S <- with(temp3,vectors%*%diag(temp5)%*%t(vectors))
  return(S)
}

