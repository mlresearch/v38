# set parameters
ds <- 48; s <- 2; tv1 <- 1; tv2 <- 0.85
d <- ds+s
ssig <- matrix(0,s,s)
diag(ssig) <- tv1
ssig[cbind(1:(s-1),2:s)] <- tv2
ssig[cbind(2:s,1:(s-1))] <- tv2
smu <- matrix(0,2,s)
smu[,1] <- c(-2,2)

tmpMu <- cbind(smu,matrix(0,2,ds))
tmpS <- diag(rep(1,ds+s)); tmpS[1:s,1:s] <- ssig
gmp <- list(n1=100,n2=100,Mu=tmpMu,S1=tmpS,S2=tmpS)

# generate data
rds <- f.r.gmmix2(gmp,seed=1001)

# apply Hardt-Price algorithm
l.pivot <- f.find.pivot(rds$X,verbose=TRUE)
l.hppars <- f.hp.fullcov(rds$X, pivot=l.pivot$best.ind, verbose=TRUE)

# apply Cai-Liu algorithm to Hardt-Price results
l.hpbetas <- matrix(0,d,length(lambdalst))
for(i in 1:length(lambdalst)) {
cat(i,"\n")
tmpso <- with(l.hppars,f.solvecai((S1+S2)/2,Mu[1,]-Mu[2,],lambda=lambdalst[i]))
l.hpbetas[,i] <- tmpso$beta
}

# apply EM
l.eminit <- init.EM(rds$X, nclass=2)
l.empars <- emcluster(rds$X, l.eminit)
tmplongsigs <- f.sig.longtolist(l.empars$LTSigma)
l.empars$S1 <- tmplongsigs$sigs[[1]]
l.empars$S2 <- tmplongsigs$sigs[[2]]

# apply Cai-Liu algorithm to EM results
l.embetas <- matrix(0,d,length(lambdalst))
for(i in 1:length(lambdalst)) {
cat(i,"\n")
tmpso <- with(l.empars,f.solvecai(S1*pi[1]+S2*pi[2],Mu[1,]-Mu[2,],lambda=lambdalst[i]))
l.embetas[,i] <- tmpso$beta
}

# perform EM initialized with true parameters
tl.empars <- emcluster(rds$X, pi=c(0.5,0.5),Mu=gmp$Mu,LTSigma=rbind(gmp$S1[upper.tri(gmp$S1,T)],gmp$S1[upper.tri(gmp$S1,T)]))
cat("comparison of log likelihoods\n")
cat("default initialization:", l.empars$llhdval,"\n")
cat("initialization with true values:", tl.empars$llhdval,"\n")

save(l.pivot,l.hppars,l.hpbetas,l.eminit,l.empars,l.embetas,file="savedata_2dstacked")

