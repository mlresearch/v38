# set parameters
ds <- 195; s <- 5
d <- ds+s
tmpBeta <- c(rep(5,s),rep(0,ds))
tmpS1 <- f.rwishart(d,seed=100)
tmpS2 <- tmpS1#f.rwishart(d,seed=101)
tmpn1 <- 75; tmpn2 <- 75; tmppi <- c(tmpn1,tmpn2)/(tmpn1+tmpn2)
tmpS <- tmppi[1]*tmpS1 + tmppi[2]*tmpS2
tmpMu <- c(tmpS%*%tmpBeta)
gmp <- list(n1=tmpn1,n2=tmpn2,Mu=rbind(tmpMu,-tmpMu),S1=tmpS1,S2=tmpS2,beta=tmpBeta)

# generate data
rds <- f.r.gmmix2(gmp,seed=1000)

# apply Hardt-Price algorithm
l.pivot <- f.find.pivot(rds$X,verbose=TRUE)
l.hppars <- f.hp.fullcov(rds$X, pivot=l.pivot$best.ind, verbose=TRUE)


# apply Cai-Liu algorithm to Hardt-Price results
l.hpbetas <- matrix(0,d,length(lambdalst2))
for(i in 1:length(lambdalst2)) {
cat(i,"\n")
tmpso <- with(l.hppars,f.solvecai(S1*pi[1]+S2*pi[2],Mu[1,]-Mu[2,],lambda=lambdalst2[i]))
l.hpbetas[,i] <- tmpso$beta
}

save(l.pivot,l.hppars,l.hpbetas,file="savedata_nonspherical2_s=5")


